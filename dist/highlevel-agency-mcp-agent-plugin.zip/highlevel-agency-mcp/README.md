# HighLevel Agency & Builder MCP

The full-stack GoHighLevel (GHL) MCP for agency owners and funnel builders — automate funnel layouts, client DNS & SSL, workflow graphs, LeadShield contact form spam & B2B solicitation blockers, spam-shield IVRs, and snapshot diffs from Claude, Cursor, ChatGPT, Grok Bot, Muse, Antigravity, and Perplexity.

## Quick start

1. Open [HighLevel Agency & Builder MCP](https://ghlagencymcp.com) in your browser or connect your MCP host to `https://ghlagencymcp.com/mcp`.

Endpoint: https://ghlagencymcp.com/mcp
Privacy: https://ghlagencymcp.com/privacy
